try: from .providers.orionoid import Orionoid # Kodi 19
except: from providers.orionoid import Orionoid
if provider == Orionoid.Id:
    max_results = Orionoid.limit()
